import numpy as np
import pandas as pd
from flask import Flask, request, render_template
import joblib

app = Flask(__name__) 

@app.route("/") 
def home():
    return render_template("index.html")#先引入index.html，同时根据后面传入的参数，对html进行修改渲染。

@app.route("/predict", methods=["POST"])
def predict():
    
      Task = request.form.get("Task")
      Mineral = request.form.get("Mineral")
      SSA = request.form.get("SSA") 
      FeO = request.form.get("Fe/O")
      Cellb = request.form.get("Cellb") 
      Metal = request.form.get("Metal")
      ONum = request.form.get("ONum") 
      Radius = request.form.get("Radius")
      Electronegativity = request.form.get("Electronegativity")
      pH = request.form.get("pH")
      Cmineral = request.form.get("Cmineral") 
      COM = request.form.get("COM")
      CMetal = request.form.get("CMetal")
      Time = request.form.get("Time")
      Temperature = request.form.get("Temperature") 
      IonicStrength = request.form.get("IonicStrength")
          
      if Task == "1":
          sc = joblib.load("Coordination type Sc")
          gcf = joblib.load("Coordination type.pkl")
        
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0]
          Bond = ["Without Fe coordination", "With Fe coordination"]
          return render_template("index.html", output = "Coordination type: {}".format(Bond[prediction]))

      if Task == "2":    
          sc = joblib.load("Me-Fe shell type Sc")
          gcf = joblib.load("Me-Fe shell type.pkl")
        
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0]
          Shell = ["Multiple Fe shell", "Single Fe shell"]
          return render_template("index.html", output = "Me-Fe shell type: {}".format(Shell[prediction]))
      
      if Task == "3":    
          sc = joblib.load("Me-O CN Sc")
          gcf = joblib.load("Me-O CN.pkl")
        
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0][0]
          
          return render_template("index.html", output = "Me-O CN: {}".format(prediction))
      
      if Task == "4":    
          sc = joblib.load("Me-O R Sc")
          gcf = joblib.load("Me-O R.pkl")
        
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0][0]
          
          return render_template("index.html", output = "Me-O R: {}".format(prediction))
      if Task == "5":    
          sc = joblib.load("Me-Fe1 CN Sc")
          gcf = joblib.load("Me-Fe1 CN.pkl")
        
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0][0]
          
          return render_template("index.html", output = "Me-Fe1 CN: {}".format(prediction))
      
      if Task == "6":    
          sc = joblib.load("Me-Fe1 R Sc")
          gcf = joblib.load("Me-Fe1 R.pkl")
        
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0][0]
          
          return render_template("index.html", output = "Me-Fe1 R: {}".format(prediction))
      
      if Task == "7":    
          sc = joblib.load("Me-Fe2 CN Sc")
          gcf = joblib.load("Me-Fe2 CN.pkl")
          Recrystallization = request.form.get("Recrystallization")
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength),int(Recrystallization)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0][0]
          
          return render_template("index.html", output = "Me-Fe2 CN: {}".format(prediction))
      
      if Task == "8":    
          sc = joblib.load("Me-Fe2 R Sc")
          gcf = joblib.load("Me-Fe2 R.pkl")
        
          X1 = pd.DataFrame([[float(Mineral), float(SSA), float(FeO), float(Cellb),float(Metal),
          float(ONum),float(Radius),float(Electronegativity),float(pH),float(Cmineral),float(COM),float(CMetal),float(Time),float(Temperature), float(IonicStrength)]])
          X2 = sc.transform(X1) 
          prediction = gcf.predict(X2)[0][0]
          
          return render_template("index.html", output = "Me-Fe2 R: {}".format(prediction))
          
app.run()







